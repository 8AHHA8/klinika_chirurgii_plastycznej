package com.example.bookmachine;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField emailField;
    @FXML
    private TextField passwordField;
    @FXML
    private Label errorInfo;
    @FXML
    private Button loginBtn;

    public void initialize() {
        errorInfo.setVisible(false);

        loginBtn.setOnAction(event -> {
            String email = emailField.getText();
            String password = passwordField.getText();

            EntityManager entityManager = Config.getEntityManager();

            StoredProcedureQuery query = entityManager
                    .createStoredProcedureQuery("LOGIN", Person.class);
            query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
            query.registerStoredProcedureParameter(3, void.class, ParameterMode.REF_CURSOR);

            query.setParameter(1, email);
            query.setParameter(2, password);

            query.execute();

            try {
                Person person = (Person) query.getSingleResult();
                errorInfo.setVisible(false);
            } catch (NullPointerException e) {
                errorInfo.setVisible(true);
            }

        });
    }
}
